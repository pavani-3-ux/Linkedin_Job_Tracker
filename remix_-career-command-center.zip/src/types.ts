export enum ApplicationStatus {
  Applied = "Applied",
  UnderReview = "Under Review",
  Assessment = "Assessment",
  InterviewScheduled = "Interview Scheduled",
  FinalRound = "Final Round",
  OfferReceived = "Offer Received",
  Accepted = "Accepted",
  Rejected = "Rejected",
  Withdrawn = "Withdrawn"
}

export interface Application {
  id: string;
  companyName: string;
  role: string;
  location: string;
  salary: string;
  applicationDate: string;
  jobLink?: string;
  recruiterName?: string;
  recruiterEmail?: string;
  notes?: string;
  status: ApplicationStatus;
}

export interface Interview {
  id: string;
  applicationId: string;
  title: string;
  date: string; // ISO String
  type: string;
  zoomLink?: string;
  notes?: string;
  feedback?: string;
  score?: number; // 1-5 rating
  completed?: boolean;
}

export interface NotificationItem {
  id: string;
  type: "interview" | "offer" | "alert" | "system";
  message: string;
  date: string;
  read: boolean;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  action: string;
}

export interface AchievementItem {
  id: string;
  badge: "First Callback" | "Dream Applied" | "First Offer" | "100 Club";
  description: string;
  unlocked: boolean;
  unlockedAt: string | null;
}

export interface DashboardMeta {
  activityLogs: ActivityLog[];
  achievements: AchievementItem[];
  streak: number;
  weeklyGoal: {
    progress: number;
    target: number;
  };
}
