import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, LabelList } from "recharts";
import { Application, ApplicationStatus } from "../types";
import { TrendingUp, BarChart3, PieChart, Users, Percent, HelpCircle } from "lucide-react";

interface AnalyticsViewProps {
  applications: Application[];
}

export function AnalyticsView({ applications }: AnalyticsViewProps) {
  // 1. Applications by Month
  // Group dates to month labels
  const getApplicationsByMonth = () => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const counts: { [key: string]: number } = { "Jan": 0, "Feb": 0, "Mar": 0, "Apr": 0, "May": 2, "Jun": 5 }; // seed historical
    
    applications.forEach((app) => {
      try {
        const date = new Date(app.applicationDate);
        if (!isNaN(date.getTime())) {
          const mLabel = months[date.getMonth()];
          counts[mLabel] = (counts[mLabel] || 0) + 1;
        }
      } catch (err) {
        // ignore parsing errors
      }
    });

    return Object.keys(counts).map((key) => ({
      name: key,
      applications: counts[key]
    }));
  };

  // 2. Applications by Company
  const getApplicationsByCompany = () => {
    const companies: { [key: string]: number } = {};
    applications.forEach((app) => {
      companies[app.companyName] = (companies[app.companyName] || 0) + 1;
    });

    return Object.keys(companies)
      .map((key) => ({ name: key, count: companies[key] }))
      .sort((a,b) => b.count - a.count)
      .slice(0, 6);
  };

  // 3. Funnel Stages calculation
  const getFunnelData = () => {
    const counts = {
      Applied: 0,
      Review: 0,
      Assessment: 0,
      Interview: 0,
      Offer: 0
    };

    applications.forEach((app) => {
      counts.Applied++; // Every app has at least been applied
      if (app.status !== ApplicationStatus.Applied) {
        counts.Review++;
      }
      if ([ApplicationStatus.Assessment, ApplicationStatus.InterviewScheduled, ApplicationStatus.FinalRound, ApplicationStatus.OfferReceived, ApplicationStatus.Accepted].includes(app.status)) {
        counts.Assessment++;
      }
      if ([ApplicationStatus.InterviewScheduled, ApplicationStatus.FinalRound, ApplicationStatus.OfferReceived, ApplicationStatus.Accepted].includes(app.status)) {
        counts.Interview++;
      }
      if ([ApplicationStatus.OfferReceived, ApplicationStatus.Accepted].includes(app.status)) {
        counts.Offer++;
      }
    });

    return [
      { stage: "Applied (Total)", value: counts.Applied, rate: 100 },
      { stage: "Review Phase", value: counts.Review, rate: Math.round((counts.Review / (counts.Applied || 1)) * 100) },
      { stage: "Assessment Step", value: counts.Assessment, rate: Math.round((counts.Assessment / (counts.Applied || 1)) * 100) },
      { stage: "Interview Held", value: counts.Interview, rate: Math.round((counts.Interview / (counts.Applied || 1)) * 100) },
      { stage: "Offer Handed", value: counts.Offer, rate: Math.round((counts.Offer / (counts.Applied || 1)) * 100) }
    ];
  };

  // Stats aggregation
  const totalAppsCount = applications.length;
  const interviewsCount = applications.filter((a) =>
    [ApplicationStatus.InterviewScheduled, ApplicationStatus.FinalRound].includes(a.status)
  ).length;
  const offersCount = applications.filter((a) =>
    [ApplicationStatus.OfferReceived, ApplicationStatus.Accepted].includes(a.status)
  ).length;
  const rejectionsCount = applications.filter((a) => a.status === ApplicationStatus.Rejected).length;

  const callbackCount = applications.filter(
    (a) => a.status !== ApplicationStatus.Applied && a.status !== ApplicationStatus.UnderReview
  ).length;
  const responseRate = totalAppsCount ? Math.round((callbackCount / totalAppsCount) * 100) : 0;
  const successRate = totalAppsCount ? Math.round((offersCount / totalAppsCount) * 100) : 0;

  return (
    <div id="analytics-section" className="space-y-6">
      {/* Dynamic Summary counters */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel p-4.5 rounded-xl border border-slate-800">
          <div className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-blue-400" />
            <span>Search Conversion</span>
          </div>
          <div className="text-2xl font-bold font-display text-white">{totalAppsCount} Logs</div>
          <div className="text-[10px] text-slate-500 mt-1">Total active application pipelines</div>
        </div>

        <div className="glass-panel p-4.5 rounded-xl border border-slate-800">
          <div className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <Percent className="w-3.5 h-3.5 text-emerald-400" />
            <span>Response callbacks</span>
          </div>
          <div className="text-2xl font-bold font-display text-emerald-400">{responseRate}%</div>
          <div className="text-[10px] text-emerald-500/80 mt-1">Target ATS matching response rate</div>
        </div>

        <div className="glass-panel p-4.5 rounded-xl border border-slate-800">
          <div className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
            <span>Interview Tracks</span>
          </div>
          <div className="text-2xl font-bold font-display text-purple-400">{interviewsCount} Held</div>
          <div className="text-[10px] text-slate-500 mt-1">Live interviews scheduled</div>
        </div>

        <div className="glass-panel p-4.5 rounded-xl border border-slate-800">
          <div className="text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1 flex items-center gap-1.5">
            <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Offer Ratio</span>
          </div>
          <div className="text-2xl font-bold font-display text-cyan-400">{successRate}%</div>
          <div className="text-[10px] text-slate-500 mt-1">Conversion of tracks to official offers</div>
        </div>
      </div>

      {/* Recharts grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Month progress */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800 relative">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 font-display">
            <TrendingUp className="w-4 h-4 text-brand-primary" />
            <span>Applications Volume Benchmark</span>
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={getApplicationsByMonth()}>
                <defs>
                  <linearGradient id="colorApps" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8", fontWeight: "bold" }}
                  itemStyle={{ color: "#38bdf8" }}
                />
                <Area type="monotone" dataKey="applications" stroke="#2563EB" strokeWidth={2} fillOpacity={1} fill="url(#colorApps)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Company Distribution */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 font-display">
            <BarChart3 className="w-4 h-4 text-brand-accent" />
            <span>Application Density - Top Target Companies</span>
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={getApplicationsByCompany()}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8" }}
                  itemStyle={{ color: "#22d3ee" }}
                />
                <Bar dataKey="count" fill="#06B6D4" radius={[4, 4, 0, 0]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Conversion Funnel */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 font-display">
            <PieChart className="w-4 h-4 text-brand-secondary" />
            <span>Interactive Interview Conversion Funnel</span>
          </h3>
          <div className="h-64 flex flex-col justify-center">
            <div className="space-y-4">
              {getFunnelData().map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-300">{item.stage}</span>
                    <span className="text-slate-450">
                      <span className="text-white font-bold">{item.value}</span> ({item.rate}%)
                    </span>
                  </div>
                  <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-850">
                    <div
                      className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 rounded-full transition-all duration-500"
                      style={{ width: `${item.rate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Chart 4: Historical Response Rates */}
        <div className="glass-panel p-5 rounded-2xl border border-slate-800">
          <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2 font-display">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>Response Velocity & Callback Trend %</span>
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={[
                { date: "M1", rate: 25 },
                { date: "M2", rate: 38 },
                { date: "M3", rate: 42 },
                { date: "M4", rate: 61 },
                { date: "M5", rate: 58 },
                { date: "Current", rate: responseRate }
              ]}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "8px" }}
                  labelStyle={{ color: "#94a3b8" }}
                />
                <Line type="monotone" dataKey="rate" stroke="#10B981" strokeWidth={3} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
