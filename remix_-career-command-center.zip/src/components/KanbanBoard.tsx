import React, { useState } from "react";
import { Application, ApplicationStatus } from "../types";
import { Briefcase, MapPin, DollarSign, Calendar, ChevronRight, CheckCircle, Flame } from "lucide-react";

interface KanbanBoardProps {
  applications: Application[];
  onUpdateStatus: (id: string, newStatus: ApplicationStatus) => void;
  onSelectApplication: (app: Application) => void;
}

interface Column {
  id: string;
  title: string;
  statuses: ApplicationStatus[];
  colorClass: string;
  badgeClass: string;
}

export function KanbanBoard({ applications, onUpdateStatus, onSelectApplication }: KanbanBoardProps) {
  const [draggedAppId, setDraggedAppId] = useState<string | null>(null);

  const columns: Column[] = [
    {
      id: "applied",
      title: "Applied",
      statuses: [ApplicationStatus.Applied, ApplicationStatus.UnderReview],
      colorClass: "border-t-2 border-t-blue-500",
      badgeClass: "bg-blue-950/40 text-blue-400 border border-blue-900/40"
    },
    {
      id: "assessment",
      title: "Assessment",
      statuses: [ApplicationStatus.Assessment],
      colorClass: "border-t-2 border-t-cyan-500",
      badgeClass: "bg-cyan-950/40 text-cyan-400 border border-cyan-900/40"
    },
    {
      id: "interview",
      title: "Interviews",
      statuses: [ApplicationStatus.InterviewScheduled, ApplicationStatus.FinalRound],
      colorClass: "border-t-2 border-t-purple-500",
      badgeClass: "bg-purple-950/40 text-purple-400 border border-purple-900/40"
    },
    {
      id: "offer",
      title: "Offers",
      statuses: [ApplicationStatus.OfferReceived, ApplicationStatus.Accepted],
      colorClass: "border-t-2 border-t-emerald-500",
      badgeClass: "bg-emerald-950/40 text-emerald-400 border border-emerald-900/40"
    },
    {
      id: "rejected",
      title: "Rejected",
      statuses: [ApplicationStatus.Rejected, ApplicationStatus.Withdrawn],
      colorClass: "border-t-2 border-t-rose-500",
      badgeClass: "bg-rose-950/40 text-rose-400 border border-rose-900/40"
    }
  ];

  const getAppsForColumn = (column: Column) => {
    return applications.filter((app) => column.statuses.includes(app.status));
  };

  const handleDragStart = (id: string) => {
    setDraggedAppId(id);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (columnId: string) => {
    if (!draggedAppId) return;

    // Map column target to a default primary status
    let targetStatus = ApplicationStatus.Applied;
    if (columnId === "applied") targetStatus = ApplicationStatus.Applied;
    else if (columnId === "assessment") targetStatus = ApplicationStatus.Assessment;
    else if (columnId === "interview") targetStatus = ApplicationStatus.InterviewScheduled;
    else if (columnId === "offer") targetStatus = ApplicationStatus.OfferReceived;
    else if (columnId === "rejected") targetStatus = ApplicationStatus.Rejected;

    onUpdateStatus(draggedAppId, targetStatus);
    setDraggedAppId(null);
  };

  return (
    <div id="kanban-section" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display">Workflow Kanban Board</h2>
          <p className="text-xs text-slate-400">Drag Cards dynamically across stages to update system pipeline statuses</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] text-slate-400">
          <Flame className="w-3.5 h-3.5 text-brand-accent animate-pulse" />
          <span>Interactive Drag & Drop Engaged</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
        {columns.map((column) => {
          const colApps = getAppsForColumn(column);
          return (
            <div
              key={column.id}
              onDragOver={handleDragOver}
              onDrop={() => handleDrop(column.id)}
              className="flex flex-col rounded-xl bg-slate-900/40 border border-slate-800 p-3.5 min-h-[500px]"
            >
              {/* Column Header */}
              <div className="flex items-center justify-between pb-3.5 border-b border-slate-850/60 mb-4 whitespace-nowrap">
                <span className="text-xs font-bold text-slate-350 font-display flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${column.id === 'offer' ? 'bg-emerald-500' : column.id === 'rejected' ? 'bg-rose-500' : 'bg-slate-500'}`} />
                  {column.title}
                </span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${column.badgeClass}`}>
                  {colApps.length}
                </span>
              </div>

              {/* Column Cards Container */}
              <div className="flex-1 space-y-3">
                {colApps.map((app) => (
                  <div
                    key={app.id}
                    draggable
                    onDragStart={() => handleDragStart(app.id)}
                    onClick={() => onSelectApplication(app)}
                    className={`group ${column.colorClass} bg-slate-950 p-3.5 rounded-xl border border-slate-850 hover:border-slate-700 hover:shadow-xl transition-all cursor-grab active:cursor-grabbing hover:-translate-y-0.5 relative overflow-hidden`}
                  >
                    {/* Hover glow line */}
                    <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-slate-700/40 to-transparent"></div>

                    {/* Meta info */}
                    <div className="flex items-start justify-between gap-1.5 mb-1">
                      <h4 className="text-xs font-bold text-white group-hover:text-brand-accent transition-colors truncate">
                        {app.companyName}
                      </h4>
                      <span className="text-[9px] text-slate-500 shrink-0 font-mono">
                        {app.applicationDate.substring(5)}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-300 font-medium truncate mb-2.5">
                      {app.role}
                    </p>

                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                        <MapPin className="w-3 h-3 text-brand-accent" />
                        <span className="truncate">{app.location}</span>
                      </div>
                      {app.salary && (
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                          <DollarSign className="w-3 h-3 text-brand-accent" />
                          <span className="truncate">{app.salary}</span>
                        </div>
                      )}
                    </div>

                    {/* Status Badge Tag */}
                    <div className="mt-3.5 flex items-center justify-between border-t border-slate-900/60 pt-2 text-[9px]">
                      <span className="text-slate-500 truncate mt-0.5">Recruiter info exists</span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-300 transition-colors" />
                    </div>
                  </div>
                ))}

                {colApps.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-slate-600 rounded-xl border border-dashed border-slate-850">
                    <Briefcase className="w-5 h-5 text-slate-800 mb-1" />
                    <span className="text-[10px] font-medium uppercase font-display">Stage Empty</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
