import { useState, useEffect } from "react";
import { Sparkles, FileText, MessageSquare, Clipboard, Compass, CheckCircle2, AlertTriangle, ArrowRight, Loader2, ThumbsUp, Send } from "lucide-react";

export function AICopilotHub() {
  const [activeTab, setActiveTab] = useState<"resume" | "interview" | "cover" | "match" | "insights">("resume");
  const [loading, setLoading] = useState(false);

  // Resume Scorer states
  const [resumeText, setResumeText] = useState("UX Designer focused on design systems, visual hierarchies, and performance metrics.");
  const [jobDescription, setJobDescription] = useState("Requirements: 5+ years building highly visual SaaS interfaces with Tailwind CSS and advanced animation libraries like Motion.");
  const [resumeResult, setResumeResult] = useState<any>(null);

  // Interview Prep states
  const [prepCompany, setPrepCompany] = useState("Stripe");
  const [prepRole, setPrepRole] = useState("Senior Frontend Architect");
  const [prepNotes, setPrepNotes] = useState("Focus on high visual fidelity, layout optimization, and interactive charting.");
  const [prepDraft, setPrepDraft] = useState("");
  const [prepResult, setPrepResult] = useState<any>(null);

  // Cover Letter states
  const [coverCompany, setCoverCompany] = useState("Notion");
  const [coverRole, setCoverRole] = useState("Lead Systems Designer");
  const [coverHighlights, setCoverHighlights] = useState("Built extensible rich-text editing canvas blocks and increased user collaboration metric by 35%.");
  const [coverResult, setCoverResult] = useState<any>(null);

  // Job Match Score states
  const [matchResult, setMatchResult] = useState<any>(null);

  // Career Insights state
  const [insightsResult, setInsightsResult] = useState<any>(null);

  // Triggers for API calls
  const runResumeScore = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/resume-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText, jobDescription })
      });
      const data = await response.json();
      setResumeResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const runInterviewPrep = async (answerSubmit = false) => {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/prep-interview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyName: prepCompany,
          roleName: prepRole,
          candidateNotes: prepNotes,
          userDraftAnswer: answerSubmit ? prepDraft : ""
        })
      });
      const data = await response.json();
      setPrepResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const runCoverLetter = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/cover-letter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyName: coverCompany,
          roleName: coverRole,
          customHighlights: coverHighlights
        })
      });
      const data = await response.json();
      setCoverResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const runJobMatch = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/match-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText, jobDescription })
      });
      const data = await response.json();
      setMatchResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const runCareerInsights = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/ai/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await response.json();
      setInsightsResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Run defaults on load
  useEffect(() => {
    runResumeScore();
  }, []);

  return (
    <div id="ai-command-center" className="glass-panel rounded-2xl p-6 border border-slate-800 relative overflow-hidden">
      {/* Background glow ambient effects */}
      <div className="absolute top-0 left-0 w-80 h-80 bg-brand-accent/5 rounded-full blur-3xl pointer-events-none -ml-40 -mt-20 animate-pulse"></div>
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl pointer-events-none -mr-40 -mb-20 animate-pulse"></div>

      {/* Header section with styling */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-1.5 text-indigo-400 text-sm font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4 fill-indigo-400" />
            <span>AI Command Center</span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">Gemini 3.5 Assistant Co-pilot</h2>
          <p className="text-sm text-slate-400">Optimize resumes, generates rich cover letters, design mock interview checkpoints</p>
        </div>

        <div className="text-xs bg-indigo-950/40 border border-indigo-800/40 rounded-lg px-3.5 py-2 flex items-center gap-2 max-w-sm">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
          <p className="text-indigo-200">
            {process.env.GEMINI_API_KEY ? "Live server-side pipeline configured" : "Local optimization sandbox active"}
          </p>
        </div>
      </div>

      {/* Internal Navigation Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 bg-slate-900/60 p-1 rounded-xl mb-6 border border-slate-800 gap-1">
        <button
          onClick={() => { setActiveTab("resume"); runResumeScore(); }}
          className={`flex items-center justify-center gap-2 text-xs md:text-sm font-medium py-2 px-1.5 rounded-lg transition-all ${
            activeTab === "resume" ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Resume ATS</span>
        </button>
        <button
          onClick={() => { setActiveTab("interview"); runInterviewPrep(false); }}
          className={`flex items-center justify-center gap-2 text-xs md:text-sm font-medium py-2 px-1.5 rounded-lg transition-all ${
            activeTab === "interview" ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Interview Prep</span>
        </button>
        <button
          onClick={() => { setActiveTab("cover"); runCoverLetter(); }}
          className={`flex items-center justify-center gap-2 text-xs md:text-sm font-medium py-2 px-1.5 rounded-lg transition-all ${
            activeTab === "cover" ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          }`}
        >
          <Clipboard className="w-4 h-4" />
          <span>Cover Letter</span>
        </button>
        <button
          onClick={() => { setActiveTab("match"); runJobMatch(); }}
          className={`flex items-center justify-center gap-2 text-xs md:text-sm font-medium py-2 px-1.5 rounded-lg transition-all ${
            activeTab === "match" ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Job Matcher</span>
        </button>
        <button
          onClick={() => { setActiveTab("insights"); runCareerInsights(); }}
          className={`flex items-center justify-center gap-2 text-xs md:text-sm font-medium py-2 px-1.5 rounded-lg transition-all ${
            activeTab === "insights" ? "bg-indigo-600 text-white shadow-lg" : "text-slate-400 hover:text-white"
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Insights</span>
        </button>
      </div>

      {/* Core Dynamic Form Interface & Results */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Input Controls */}
        <div className="lg:col-span-5 space-y-4">
          {activeTab === "resume" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Resume Snapshot Keywords</label>
                <textarea
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  className="w-full h-32 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors scrollbar-thin resize-none"
                  placeholder="Paste your resume core achievements and keywords..."
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Target Job Description</label>
                <textarea
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  className="w-full h-32 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors scrollbar-thin resize-none"
                  placeholder="Paste target role requirements here..."
                />
              </div>
              <button
                onClick={runResumeScore}
                className="w-full bg-brand-primary text-white py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Calculate ATS Alignment</span>
              </button>
            </>
          )}

          {activeTab === "interview" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Target Company</label>
                  <input
                    type="text"
                    value={prepCompany}
                    onChange={(e) => setPrepCompany(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-accent"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Target Role</label>
                  <input
                    type="text"
                    value={prepRole}
                    onChange={(e) => setPrepRole(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-accent"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Interview Context/Notes</label>
                <input
                  type="text"
                  value={prepNotes}
                  onChange={(e) => setPrepNotes(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-brand-accent"
                  placeholder="E.g., round topic guidelines"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Your Draft Answer (AI Review Block)</label>
                <textarea
                  value={prepDraft}
                  onChange={(e) => setPrepDraft(e.target.value)}
                  className="w-full h-32 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors scrollbar-thin resize-none"
                  placeholder="Draft your answer here to let Gemini critique and sharpen details..."
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => runInterviewPrep(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-200 py-2.5 rounded-xl font-medium text-sm transition-colors border border-slate-700"
                  disabled={loading}
                >
                  Regen Questions
                </button>
                <button
                  onClick={() => runInterviewPrep(true)}
                  className="flex-1 bg-brand-primary text-white py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                  disabled={loading}
                >
                  Submit Answer
                </button>
              </div>
            </>
          )}

          {activeTab === "cover" && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Company Name</label>
                  <input
                    type="text"
                    value={coverCompany}
                    onChange={(e) => setCoverCompany(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-300">Role Title</label>
                  <input
                    type="text"
                    value={coverRole}
                    onChange={(e) => setCoverRole(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Personal highlights & impacts to feature</label>
                <textarea
                  value={coverHighlights}
                  onChange={(e) => setCoverHighlights(e.target.value)}
                  className="w-full h-44 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none scrollbar-thin resize-none"
                />
              </div>
              <button
                onClick={runCoverLetter}
                className="w-full bg-brand-primary text-white py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Generate Cover Letter</span>
              </button>
            </>
          )}

          {activeTab === "match" && (
            <>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Verify Resume Credentials</label>
                <textarea
                  value={resumeText}
                  onChange={(e) => setResumeText(e.target.value)}
                  className="w-full h-30 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors scrollbar-thin resize-none"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300">Target Specifications</label>
                <textarea
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  className="w-full h-30 bg-slate-950 border border-slate-800 rounded-xl px-4.5 py-3 text-sm text-white focus:outline-none focus:border-brand-accent transition-colors scrollbar-thin resize-none"
                />
              </div>
              <button
                onClick={runJobMatch}
                className="w-full bg-brand-primary text-white py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-colors"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Analyze Skill Matrix Match</span>
              </button>
            </>
          )}

          {activeTab === "insights" && (
            <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800 text-center">
              <Compass className="w-10 h-10 text-indigo-400 mx-auto mb-3" />
              <h3 className="text-sm font-semibold text-slate-100 mb-1">Applications Market Map</h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                Analyze active tracking applications to build structural strategies for salary benchmarks and negotiation ranges.
              </p>
              <button
                onClick={runCareerInsights}
                className="w-full bg-brand-primary text-white py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-blue-750 transition-all"
                disabled={loading}
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Assemble Active Insights</span>
              </button>
            </div>
          )}
        </div>

        {/* Results Panels with Sleek Styling */}
        <div className="lg:col-span-7 bg-slate-950 rounded-xl border border-slate-850 p-5 min-h-[380px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-900 pb-3 mb-4">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                <span>Copilot Analysis Output</span>
              </span>
              <span className="text-xs text-brand-accent/80 flex items-center gap-1">
                <span>Power Mode:</span>
                <span className="font-bold">Gemini 3.5</span>
              </span>
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 gap-3">
                <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                <p className="text-xs text-slate-400 font-medium">Assembling tokens, analyzing specifications with Gemini...</p>
              </div>
            ) : (
              <>
                {/* 1. Resume Results */}
                {activeTab === "resume" && resumeResult && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4 bg-slate-900/55 p-4 rounded-xl border border-slate-800">
                      <div className="w-14 h-14 rounded-full bg-indigo-950 border-2 border-indigo-500/30 flex items-center justify-center font-bold font-display text-indigo-350 text-xl shadow-inner pulse-glow">
                        {resumeResult.score}%
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold text-slate-205">ATS Alignment Coefficient</h4>
                        <p className="text-xs text-slate-400 leading-relaxed mt-0.5">{resumeResult.overview}</p>
                      </div>
                    </div>

                    <div className="space-y-2.5">
                      <h4 className="text-xs font-bold text-slate-350 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-brand-warning" />
                        <span>Crucial ATS Adjustments Required</span>
                      </h4>
                      <ul className="space-y-1.5">
                        {resumeResult.suggestions && resumeResult.suggestions.map((s: string, idx: number) => (
                          <li key={idx} className="text-xs text-slate-300 leading-relaxed flex items-start gap-1.5">
                            <span className="text-brand-accent font-bold mt-0.5">•</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="border-t border-slate-900 pt-3.5 mt-2">
                      <h4 className="text-xs font-bold text-slate-400 mb-1">Technical Skill Assessment Fit</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">{resumeResult.fitAnalysis}</p>
                    </div>
                  </div>
                )}

                {/* 2. Interview Prep Results */}
                {activeTab === "interview" && prepResult && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-bold text-white mb-2">Practice Questions (Try draft-answering)</h4>
                    <div className="space-y-3">
                      {prepResult.questions && prepResult.questions.map((q: any, idx: number) => (
                        <div key={q.id || idx} className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800">
                          <p className="text-xs font-semibold text-slate-202 leading-relaxed">
                            <span className="text-brand-accent font-bold">Q{idx + 1}:</span> {q.question}
                          </p>
                          <p className="text-[11px] text-slate-450 mt-1.5 italic bg-slate-950 px-2 py-1.5 rounded border border-slate-900 leading-relaxed">
                            <span className="font-semibold text-indigo-400">Coach hint:</span> {q.hint}
                          </p>
                        </div>
                      ))}
                    </div>

                    {prepResult.feedback && (
                      <div className="border-t border-slate-900 pt-3 bg-indigo-950/20 p-3 rounded-lg border border-indigo-800/10 mt-3">
                        <h4 className="text-xs font-bold text-indigo-300 flex items-center gap-1 mb-1">
                          <ThumbsUp className="w-3.5 h-3.5 fill-indigo-400/10" />
                          <span>AI Coach Answer Evaluation</span>
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed">{prepResult.feedback}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* 3. Cover Letter Results */}
                {activeTab === "cover" && coverResult && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-400">Tailored Cover Letter Output</h4>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(coverResult.letter);
                          alert("Cover letter copied to clipboard!");
                        }}
                        className="text-[11px] text-brand-accent hover:underline flex items-center gap-1"
                      >
                        Copy Entire Text
                      </button>
                    </div>
                    <textarea
                      readOnly
                      value={coverResult.letter}
                      className="w-full h-80 bg-slate-900 border border-slate-800 rounded-xl px-4.5 py-3 text-xs text-slate-300 font-mono focus:outline-none scrollbar-thin resize-none leading-relaxed"
                    />
                  </div>
                )}

                {/* 4. Job Match Results */}
                {activeTab === "match" && matchResult && (
                  <div className="space-y-5">
                    <div className="text-center py-4 bg-slate-900/45 rounded-xl border border-slate-850">
                      <div className="text-3xl font-bold font-display text-brand-accent mb-0.5">{matchResult.score}%</div>
                      <div className="text-[11px] font-semibold tracking-wide text-indigo-300 uppercase">Interactive Skill Compatibility Index</div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-slate-400">Factor Evaluation Matrix</h4>
                      {matchResult.factors && matchResult.factors.map((f: any, idx: number) => (
                        <div key={idx} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-300 font-medium">{f.label}</span>
                            <span className="text-brand-accent font-semibold">{f.value}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-slate-850 rounded-full overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full" style={{ width: `${f.value}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-slate-900 pt-3">
                      <h4 className="text-xs font-bold text-brand-danger/90 mb-1">Identified Keyword Gaps (Add these for resume safety)</h4>
                      <div className="flex flex-wrap gap-1.5 mt-1.5">
                        {matchResult.unmatchedKeywords && matchResult.unmatchedKeywords.map((k: string, idx: number) => (
                          <span key={idx} className="text-[10px] bg-red-950/20 border border-red-900/30 text-rose-300 px-2 py-0.5 rounded-full">
                            {k}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 5. Insights Results */}
                {activeTab === "insights" && insightsResult && (
                  <div className="space-y-4">
                    <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                      <h4 className="text-xs font-bold text-indigo-350 uppercase mb-1">Macro Market Trend</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{insightsResult.marketInsight}</p>
                    </div>

                    <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800">
                      <h4 className="text-xs font-bold text-teal-350 uppercase mb-1">Tailored Portfolio Strategy</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{insightsResult.personalStrategy}</p>
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide">Key Recommended Steps</h4>
                      <div className="space-y-1.5">
                        {insightsResult.recommendedActions && insightsResult.recommendedActions.map((a: string, idx: number) => (
                          <div key={idx} className="flex items-start gap-2 text-xs bg-slate-900/30 p-2.5 rounded-lg border border-slate-850/60">
                            <ArrowRight className="w-3.5 h-3.5 text-brand-accent shrink-0 mt-0.5" />
                            <span className="text-slate-202 leading-relaxed">{a}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {!resumeResult && !prepResult && !coverResult && !matchResult && !insightsResult && (
                  <div className="flex flex-col items-center justify-center py-20 text-center text-slate-450 gap-2">
                    <Sparkles className="w-8 h-8 text-slate-700" />
                    <p className="text-xs">No active operation payload tracked yet. Select your copilot module and run action.</p>
                  </div>
                )}
              </>
            )}
          </div>

          <div className="text-[10px] text-slate-500 leading-relaxed border-t border-slate-900 pt-3 mt-4 flex items-center justify-between">
            <span>Powered by google/genai Models - Fully optimized in standard full stack server modules.</span>
            <span>Target: gemini-3.5-flash</span>
          </div>
        </div>
      </div>
    </div>
  );
}
