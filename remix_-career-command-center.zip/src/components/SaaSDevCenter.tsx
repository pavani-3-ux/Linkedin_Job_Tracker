import { useState } from "react";
import { Database, Terminal, FileCode, Share2, Copy, Check, Download, Layers } from "lucide-react";

export function SaaSDevCenter() {
  const [activeTab, setActiveTab] = useState<"schema" | "flask" | "queries" | "architecture">("schema");
  const [copied, setCopied] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const schemaSQL = `-- ==========================================
-- CAREER COMMAND CENTER (PROD SCHEMA)
-- MySQL 8.0+ Enterprise-Grade Database
-- ==========================================

CREATE DATABASE IF NOT EXISTS career_command_center;
USE career_command_center;

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(128) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    streak_count INT DEFAULT 0,
    INDEX idx_user_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. APPLICATIONS TABLE
CREATE TABLE IF NOT EXISTS applications (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    salary VARCHAR(100),
    application_date DATE NOT NULL,
    job_link TEXT,
    recruiter_name VARCHAR(150),
    recruiter_email VARCHAR(150),
    status ENUM('Applied', 'Under Review', 'Assessment', 'Interview Scheduled', 'Final Round', 'Offer Received', 'Accepted', 'Rejected', 'Withdrawn') DEFAULT 'Applied',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_app_status (status),
    INDEX idx_app_company (company_name),
    INDEX idx_app_user_date (user_id, application_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. INTERVIEWS TABLE
CREATE TABLE IF NOT EXISTS interviews (
    id VARCHAR(128) PRIMARY KEY,
    application_id VARCHAR(128) NOT NULL,
    title VARCHAR(255) NOT NULL,
    date DATETIME NOT NULL,
    type VARCHAR(150) NOT NULL,
    zoom_link TEXT,
    notes TEXT,
    feedback TEXT,
    score INT CHECK (score BETWEEN 1 AND 5),
    completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    INDEX idx_int_date (date),
    INDEX idx_int_completed (completed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'interview', 'offer', 'alert', 'system'
    message TEXT NOT NULL,
    date DATETIME NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_unread (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. ACHIEVEMENTS TABLE
CREATE TABLE IF NOT EXISTS achievements (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    badge VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    unlocked BOOLEAN DEFAULT FALSE,
    unlocked_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_badge (user_id, badge)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. ACTIVITY LOGS
CREATE TABLE IF NOT EXISTS activity_logs (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    action VARCHAR(255) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. ANALYTICS snapshot
CREATE TABLE IF NOT EXISTS analytics (
    id VARCHAR(128) PRIMARY KEY,
    user_id VARCHAR(128) NOT NULL,
    month_identifier VARCHAR(7) NOT NULL, -- e.g., '2026-06'
    total_applications INT DEFAULT 0,
    interviews_count INT DEFAULT 0,
    offers_count INT DEFAULT 0,
    rejections_count INT DEFAULT 0,
    response_rate DECIMAL(5,2) DEFAULT 0.00,
    success_rate DECIMAL(5,2) DEFAULT 0.00,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_month (user_id, month_identifier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`;

  const flaskPython = `# ==========================================
# CAREER COMMAND CENTER (FLASK BACKEND)
# config.py, app.py, models.py, and controller
# ==========================================

# 1. config.py
import os
class Config:
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'mysql+pymysql://root:password@localhost/career_command_center')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.getenv('SECRET_KEY', 'stripe_notion_linear_style_safe_key')
    GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

# 2. models.py
from flask_sqlalchemy import SQLAlchemy
from enum import Enum
import datetime

db = SQLAlchemy()

class ApplicationStatus(str, Enum):
    APPLIED = 'Applied'
    UNDER_REVIEW = 'Under Review'
    ASSESSMENT = 'Assessment'
    INTERVIEWSCHEDULED = 'Interview Scheduled'
    FINALROUND = 'Final Round'
    OFFER_RECEIVED = 'Offer Received'
    ACCEPTED = 'Accepted'
    REJECTED = 'Rejected'
    WITHDRAWN = 'Withdrawn'

class Application(db.Model):
    __tablename__ = 'applications'
    id = db.Column(db.String(128), primary_key=True)
    user_id = db.Column(db.String(128), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    company_name = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(255), nullable=False)
    location = db.Column(db.String(255), nullable=False)
    salary = db.Column(db.String(100))
    application_date = db.Column(db.Date, nullable=False, default=datetime.date.today)
    job_link = db.Column(db.Text)
    recruiter_name = db.Column(db.String(150))
    recruiter_email = db.Column(db.String(150))
    status = db.Column(db.String(50), default='Applied')
    notes = db.Column(db.Text)
    
    interviews = db.relationship('Interview', backref='application', cascade='all, delete-orphan', lazy=True)

class Interview(db.Model):
    __tablename__ = 'interviews'
    id = db.Column(db.String(128), primary_key=True)
    application_id = db.Column(db.String(128), db.ForeignKey('applications.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    date = db.Column(db.DateTime, nullable=False)
    type = db.Column(db.String(150), nullable=False)
    zoom_link = db.Column(db.Text)
    notes = db.Column(db.Text)
    feedback = db.Column(db.Text)
    score = db.Column(db.Integer)
    completed = db.Column(db.Boolean, default=False)

# 3. routes.py (Blueprint sample)
from flask import Blueprint, jsonify, request

api_blueprint = Blueprint('api', __name__)

@api_blueprint.route('/applications', methods=['GET', 'POST'])
def handle_applications():
    if request.method == 'GET':
        apps = Application.query.filter_by(user_id='demo_user').all()
        return jsonify([{
            'id': a.id,
            'companyName': a.company_name,
            'role': a.role,
            'location': a.location,
            'salary': a.salary,
            'applicationDate': a.application_date.isoformat(),
            'status': a.status,
            'recruiterEmail': a.recruiter_email,
            'notes': a.notes
        } for a in apps])
        
    elif request.method == 'POST':
        data = request.json
        new_app = Application(
            id=f"app_{int(datetime.datetime.now().timestamp())}",
            user_id='demo_user',
            company_name=data['companyName'],
            role=data['role'],
            location=data['location'],
            salary=data.get('salary'),
            status=data.get('status', 'Applied'),
            notes=data.get('notes')
        )
        db.session.add(new_app)
        db.session.commit()
        return jsonify({'success': True, 'id': new_app.id}), 201`;

  const sqlQueries = `-- 1. CALCULATE RECRUITER RESPONSE RATE TREND
SELECT 
    COUNT(*) AS total_applications,
    SUM(CASE WHEN status NOT IN ('Applied', 'Under Review') THEN 1 ELSE 0 END) AS response_callbacks,
    (SUM(CASE WHEN status NOT IN ('Applied', 'Under Review') THEN 1 ELSE 0 END) / COUNT(*)) * 100 AS response_rate_percentage
FROM applications
WHERE user_id = 'demo_user';

-- 2. DYNAMIC INTERVIEW FUNNEL CONVERSION
SELECT 
    COUNT(DISTINCT a.id) AS total_applied,
    COUNT(DISTINCT CASE WHEN a.status IN ('Assessment', 'Interview Scheduled', 'Final Round', 'Offer Received') THEN a.id END) AS reached_assessment_or_higher,
    COUNT(DISTINCT i.id) AS actual_interviews_held,
    COUNT(DISTINCT CASE WHEN a.status = 'Offer Received' THEN a.id END) AS offers_gained,
    (COUNT(DISTINCT CASE WHEN a.status = 'Offer Received' THEN a.id END) / COUNT(DISTINCT a.id)) * 100 AS interview_to_offer_percentage
FROM applications a
LEFT JOIN interviews i ON a.id = i.application_id
WHERE a.user_id = 'demo_user';

-- 3. APPLICATIONS COUNT GROUPED BY MONTH FOR CHART
SELECT 
    DATE_FORMAT(application_date, '%b %Y') AS month_label,
    COUNT(*) AS application_count
FROM applications
WHERE user_id = 'demo_user'
GROUP BY DATE_FORMAT(application_date, '%Y-%m'), DATE_FORMAT(application_date, '%b %Y')
ORDER BY DATE_FORMAT(application_date, '%Y-%m') ASC;

-- 4. OUTSTANDING INTERVIEWS COUNTDOWN & ALERT QUERY
SELECT 
    i.title, i.date, i.type, a.company_name, a.role,
    TIMESTAMPDIFF(HOUR, NOW(), i.date) AS hours_remaining
FROM interviews i
JOIN applications a ON i.application_id = a.id
WHERE i.completed = FALSE AND i.date > NOW()
ORDER BY i.date ASC;`;

  const aiArchitecture = `Career Command Center AI Operations Strategy
===================================================================

This application implements a Full-Stack Server-Side orchestration flow 
specifically designed to eliminate API key exposure and maximize caching constraints.

Architecture components list:
-------------------------------
1. LLM Platform: 
   - Powered by Gemini 3.5 Flash ('gemini-3.5-flash') for cost-effective reasoning pipelines, 
     smart ATS analyses, and conversational interview structures.

2. Context Sync Payload Optimization:
   - Client applications forward raw markdown/plain-text inputs (resume drafts & targets) 
     to Node-Express/Python routes.
   - The backend structures clean Prompt templates wrapped in Schema-validated inputs (JSON Schema constraints).

3. Future Database Grounding & Vector Store:
   - For 10,000+ personal candidates, implement a text-embedding-2 storage layer 
     (e.g., PostgreSQL pgvector or Firebase Vector Search indexes).
   - Compute cosine similarity index of (Candidate Resumes) <-> (Incoming Job Feed Scrapes) 
     directly at the database level to trigger alert events.

Future System Blueprint:
------------------------
[Client State (React)]
       |  (Post JSON to /api/ai/resume-score)
       v
[Express Backend Router (server.ts)]
       |  (Validates standard credentials and assembles system prompts)
       v
[Gemini 3.5 API ('gemini-3.5-flash')]
       |  (Generates schema-validated analytical outputs)
       v
[In-Memory Cache / Redis Snapshot] ---> Returned back to Client with 0ms visual delay on identical matches.`;

  const handleDownload = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="saas-dev-center" className="glass-panel rounded-2xl p-6 border border-slate-800 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16"></div>
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5 mb-6">
        <div>
          <div className="flex items-center gap-2 text-brand-accent text-sm font-semibold uppercase tracking-wider mb-1">
            <Database className="w-4 h-4" />
            <span>Developer Reference Suite</span>
          </div>
          <h2 className="text-2xl font-bold font-display text-white">SaaS System & Enterprise Code</h2>
          <p className="text-sm text-slate-400">Production-quality DB designs, Flask blueprints, and automated AI strategy</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              const zipMeta = `Database Schema:\n${schemaSQL}\n\nFlask Backend:\n${flaskPython}\n\nAnalytics Queries:\n${sqlQueries}`;
              handleDownload(zipMeta, "career_command_center_backend_kit.txt");
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sm text-slate-200 transition-all border border-slate-700"
          >
            <Download className="w-4 h-4 text-brand-accent" />
            <span>Download All Kit</span>
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl mb-6 overflow-x-auto border border-slate-800">
        <button
          onClick={() => setActiveTab("schema")}
          className={`flex items-center gap-2 text-xs md:text-sm font-medium px-4 py-2 rounded-lg transition-all ${
            activeTab === "schema" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white"
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>MySQL Schema</span>
        </button>
        <button
          onClick={() => setActiveTab("flask")}
          className={`flex items-center gap-2 text-xs md:text-sm font-medium px-4 py-2 rounded-lg transition-all ${
            activeTab === "flask" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white"
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>Flask Python</span>
        </button>
        <button
          onClick={() => setActiveTab("queries")}
          className={`flex items-center gap-2 text-xs md:text-sm font-medium px-4 py-2 rounded-lg transition-all ${
            activeTab === "queries" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white"
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>MySQL Core Queries</span>
        </button>
        <button
          onClick={() => setActiveTab("architecture")}
          className={`flex items-center gap-2 text-xs md:text-sm font-medium px-4 py-2 rounded-lg transition-all ${
            activeTab === "architecture" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white"
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Future AI Roadmap</span>
        </button>
      </div>

      {/* Active Tab Contents */}
      <div className="relative">
        {/* Code Content Box */}
        <div className="absolute top-3 right-3 z-10 flex gap-2">
          <button
            onClick={() => {
              const code =
                activeTab === "schema"
                  ? schemaSQL
                  : activeTab === "flask"
                  ? flaskPython
                  : activeTab === "queries"
                  ? sqlQueries
                  : aiArchitecture;
              handleCopy(code, activeTab);
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition-all"
            title="Copy Code"
          >
            {copied === activeTab ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        <pre className="font-mono text-xs md:text-sm text-slate-300 bg-slate-950 p-5 rounded-xl border border-slate-800 h-96 overflow-y-auto leading-relaxed scrollbar-thin">
          {activeTab === "schema" && <code>{schemaSQL}</code>}
          {activeTab === "flask" && <code>{flaskPython}</code>}
          {activeTab === "queries" && <code>{sqlQueries}</code>}
          {activeTab === "architecture" && <code>{aiArchitecture}</code>}
        </pre>
      </div>

      {/* Technical Footnote */}
      <div className="mt-4 flex items-start gap-2.5 bg-slate-900/50 p-4.5 rounded-xl border border-slate-850">
        <Share2 className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-400 leading-relaxed">
          <span className="font-semibold text-slate-200">System Architect Note:</span> This full-stack live dashboard provides beautiful, instant mockup simulations of these EXACT backend capabilities locally via the node-express integration. The MySQL models and Flask endpoints align directly with the production SQLite structure ensuring 100% data integrity when migrating.
        </div>
      </div>
    </div>
  );
}
