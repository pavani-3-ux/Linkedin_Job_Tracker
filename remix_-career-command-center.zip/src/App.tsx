import React, { useState, useEffect } from "react";
import {
  LayoutDashboard,
  Briefcase,
  History,
  CalendarDays,
  Settings,
  Sparkles,
  Database,
  Search,
  Plus,
  Trash2,
  Edit3,
  ExternalLink,
  ChevronRight,
  Bell,
  Clock,
  User,
  LogOut,
  SlidersHorizontal,
  Download,
  Award,
  AlertCircle,
  Moon,
  Sun,
  Flame,
  CheckCircle,
  FileSpreadsheet,
  FileCode2,
  ChevronDown,
  Info,
  Loader2
} from "lucide-react";

import { Application, ApplicationStatus, Interview, NotificationItem, ActivityLog, AchievementItem, DashboardMeta } from "./types";
import { SaaSDevCenter } from "./components/SaaSDevCenter";
import { AICopilotHub } from "./components/AICopilotHub";
import { KanbanBoard } from "./components/KanbanBoard";
import { AnalyticsView } from "./components/AnalyticsView";

export default function App() {
  // Navigation Menu Tabs
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "applications" | "interviews" | "kanban" | "copilot" | "database" | "achievements" | "settings"
  >("dashboard");

  // Core Data States
  const [applications, setApplications] = useState<Application[]>([]);
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [dashboardMeta, setDashboardMeta] = useState<DashboardMeta>({
    activityLogs: [],
    achievements: [],
    streak: 8,
    weeklyGoal: { progress: 3, target: 5 }
  });

  // UI State Managers
  const [loading, setLoading] = useState(true);
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true); // Default high-fidelity dark mode
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"date" | "salary" | "company">("date");

  // App Modal Managers
  const [isAppModalOpen, setIsAppModalOpen] = useState(false);
  const [editingApp, setEditingApp] = useState<Application | null>(null);

  // App Form States
  const [formCompany, setFormCompany] = useState("");
  const [formRole, setFormRole] = useState("");
  const [formLocation, setFormLocation] = useState("");
  const [formSalary, setFormSalary] = useState("");
  const [formDate, setFormDate] = useState("");
  const [formJobLink, setFormJobLink] = useState("");
  const [formRecruiterName, setFormRecruiterName] = useState("");
  const [formRecruiterEmail, setFormRecruiterEmail] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formStatus, setFormStatus] = useState<ApplicationStatus>(ApplicationStatus.Applied);

  // Interview Modal States
  const [isIntModalOpen, setIsIntModalOpen] = useState(false);
  const [selectedAppForInt, setSelectedAppForInt] = useState<string>("");
  const [formIntTitle, setFormIntTitle] = useState("");
  const [formIntDate, setFormIntDate] = useState("");
  const [formIntType, setFormIntType] = useState("");
  const [formIntZoom, setFormIntZoom] = useState("");
  const [formIntNotes, setFormIntNotes] = useState("");

  // Detailed Modal/Pane for view application
  const [viewingAppDetails, setViewingAppDetails] = useState<Application | null>(null);

  // Initial Data Synchronization Fetchers
  const syncAllData = async () => {
    try {
      const [appsRes, intsRes, notifsRes, metaRes] = await Promise.all([
        fetch("/api/applications"),
        fetch("/api/interviews"),
        fetch("/api/notifications"),
        fetch("/api/dashboard-meta")
      ]);

      const apps = await appsRes.json();
      const ints = await intsRes.json();
      const notifs = await notifsRes.json();
      const meta = await metaRes.json();

      setApplications(apps);
      setInterviews(ints);
      setNotifications(notifs);
      setDashboardMeta(meta);
    } catch (err) {
      console.error("Critical: Frontend data pipeline retrieval failed", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    syncAllData();
  }, []);

  // --- PERSISTENCE MUTATORS ---

  // Add / Edit Application trigger
  const handleAppSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCompany || !formRole) {
      alert("Company Name and Role title are mandatory metrics.");
      return;
    }

    const payload = {
      companyName: formCompany,
      role: formRole,
      location: formLocation || "Remote",
      salary: formSalary,
      applicationDate: formDate || new Date().toISOString().substring(0, 10),
      jobLink: formJobLink,
      recruiterName: formRecruiterName,
      recruiterEmail: formRecruiterEmail,
      status: formStatus,
      notes: formNotes
    };

    try {
      if (editingApp) {
        // Edit Mode
        const res = await fetch(`/api/applications/${editingApp.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          syncAllData();
          closeAppModal();
        }
      } else {
        // Create Mode
        const res = await fetch("/api/applications", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        if (res.ok) {
          syncAllData();
          closeAppModal();
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const deleteApplicationRecord = async (id: string) => {
    if (!confirm("Are you sure you want to permanently delete this application index? All coupled interviews will delete as well.")) return;
    try {
      const res = await fetch(`/api/applications/${id}`, { method: "DELETE" });
      if (res.ok) {
        if (viewingAppDetails?.id === id) setViewingAppDetails(null);
        syncAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Drag and Drop Pipeline trigger
  const handleUpdateAppStatus = async (id: string, newStatus: ApplicationStatus) => {
    try {
      const res = await fetch(`/api/applications/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        syncAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Schedule New Interview Event
  const handleIntSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAppForInt || !formIntTitle || !formIntDate) {
      alert("Requires selection of linked track, interviewer title and event date.");
      return;
    }

    const payload = {
      applicationId: selectedAppForInt,
      title: formIntTitle,
      date: new Date(formIntDate).toISOString(),
      type: formIntType || "Standard Technical Interview",
      zoomLink: formIntZoom,
      notes: formIntNotes
    };

    try {
      const res = await fetch("/api/interviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        syncAllData();
        closeIntModal();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Dismiss user notifications
  const handleDismissNotification = async (id: string) => {
    try {
      const res = await fetch(`/api/notifications/${id}/read`, { method: "POST" });
      if (res.ok) {
        syncAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Seeding Default mockup records
  const handleResetSeedData = async () => {
    if (!confirm("Warning: Resetting will clear all current records and restore standard linear premium sandbox data. Process?")) return;
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      if (res.ok) {
        syncAllData();
        setActiveTab("dashboard");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // --- MODAL UTILS ---
  const openAppModal = (app: Application | null = null) => {
    if (app) {
      setEditingApp(app);
      setFormCompany(app.companyName);
      setFormRole(app.role);
      setFormLocation(app.location);
      setFormSalary(app.salary);
      setFormDate(app.applicationDate);
      setFormJobLink(app.jobLink || "");
      setFormRecruiterName(app.recruiterName || "");
      setFormRecruiterEmail(app.recruiterEmail || "");
      setFormNotes(app.notes || "");
      setFormStatus(app.status);
    } else {
      setEditingApp(null);
      setFormCompany("");
      setFormRole("");
      setFormLocation("Remote");
      setFormSalary("");
      setFormDate(new Date().toISOString().substring(0, 10));
      setFormJobLink("");
      setFormRecruiterName("");
      setFormRecruiterEmail("");
      setFormNotes("");
      setFormStatus(ApplicationStatus.Applied);
    }
    setIsAppModalOpen(true);
  };

  const closeAppModal = () => {
    setIsAppModalOpen(false);
    setEditingApp(null);
  };

  const openIntModal = (appId: string = "") => {
    setSelectedAppForInt(appId || (applications[0]?.id || ""));
    setFormIntTitle("");
    setFormIntDate(new Date(Date.now() + 86400000 * 2).toISOString().substring(0, 16)); // Default 2 days ahead
    setFormIntType("Technical Screening");
    setFormIntZoom("");
    setFormIntNotes("");
    setIsIntModalOpen(true);
  };

  const closeIntModal = () => {
    setIsIntModalOpen(false);
  };

  // --- EXPORT IMPLEMENTATIONS ---
  const exportToCSV = () => {
    const headers = [
      "Company Name",
      "Role Title",
      "Location Type",
      "Compensation Rate",
      "Application Log Date",
      "Current Status",
      "Contact Recruiter",
      "Contact Email",
      "Strategic Notes"
    ];
    const rows = applications.map((app) => [
      app.companyName,
      app.role,
      app.location,
      app.salary,
      app.applicationDate,
      app.status,
      app.recruiterName || "",
      app.recruiterEmail || "",
      app.notes || ""
    ]);

    const csvContent = [headers, ...rows]
      .map((row) => row.map((cell) => `"${(cell || "").toString().replace(/"/g, '""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "career_command_center_logs.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToExcelFormat = () => {
    // XLS fallback structure utilizing tab separators
    const headers = ["ID", "Company", "Target Role", "Compensation", "Date Added", "Stage Status"];
    const rows = applications.map((app) => [app.id, app.companyName, app.role, app.salary, app.applicationDate, app.status]);
    const excelContent = [headers, ...rows].map((row) => row.join("\t")).join("\n");
    const blob = new Blob([excelContent], { type: "application/vnd.ms-excel;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "career_command_center_audit.xls");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- ADVANCED SEARCH FILTER COMPUTATIONS ---
  const filteredAndSortedApps = applications
    .filter((app) => {
      const matchSearch =
        app.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (app.notes && app.notes.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchStatus = statusFilter === "All" || app.status === statusFilter;

      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      if (sortBy === "company") {
        return a.companyName.localeCompare(b.companyName);
      } else if (sortBy === "salary") {
        const salA = parseFloat(a.salary.replace(/[^0-9.]/g, "")) || 0;
        const salB = parseFloat(b.salary.replace(/[^0-9.]/g, "")) || 0;
        return salB - salA;
      } else {
        // Default Sort Date
        return new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime();
      }
    });

  // COUNTDOWN UTILS
  const getDaysUntil = (isoDateStr: string) => {
    const diffTime = new Date(isoDateStr).getTime() - Date.now();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays < 0) return "Completed";
    if (diffDays === 0) return "Today";
    return `${diffDays}d left`;
  };

  // STATUS BADGE COLOR SCHEME GENERATOR
  const getStatusStyle = (status: ApplicationStatus) => {
    switch (status) {
      case ApplicationStatus.Applied:
        return "bg-blue-500/10 text-blue-400 border border-blue-500/20";
      case ApplicationStatus.UnderReview:
        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case ApplicationStatus.Assessment:
        return "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20";
      case ApplicationStatus.InterviewScheduled:
        return "bg-purple-500/10 text-purple-400 border border-purple-500/20";
      case ApplicationStatus.FinalRound:
        return "bg-pink-500/10 text-pink-400 border border-pink-500/20";
      case ApplicationStatus.OfferReceived:
        return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
      case ApplicationStatus.Accepted:
        return "bg-teal-500/10 text-teal-400 border border-teal-500/20";
      case ApplicationStatus.Rejected:
        return "bg-red-500/10 text-red-400 border border-red-500/20";
      case ApplicationStatus.Withdrawn:
        return "bg-slate-505/10 text-slate-400 border border-slate-500/20";
      default:
        return "bg-slate-800 text-slate-300";
    }
  };

  // STATS CARD CALCULATIONS
  const totalAppsCount = applications.length;
  const interviewsCount = applications.filter((a) =>
    [ApplicationStatus.InterviewScheduled, ApplicationStatus.FinalRound].includes(a.status)
  ).length;
  const offersCount = applications.filter((a) =>
    [ApplicationStatus.OfferReceived, ApplicationStatus.Accepted].includes(a.status)
  ).length;
  const rejectionsCount = applications.filter((a) => a.status === ApplicationStatus.Rejected).length;

  const callbackCount = applications.filter(
    (a) => a.status !== ApplicationStatus.Applied && a.status !== ApplicationStatus.UnderReview
  ).length;
  const responseRate = totalAppsCount ? Math.round((callbackCount / totalAppsCount) * 100) : 0;
  const successRate = totalAppsCount ? Math.round((offersCount / totalAppsCount) * 100) : 0;

  const appsThisMonthCount = applications.filter((a) => {
    const appDate = new Date(a.applicationDate);
    const now = new Date();
    return appDate.getMonth() === now.getMonth() && appDate.getFullYear() === now.getFullYear();
  }).length;

  const nextUpcomingInterview = interviews
    .filter((i) => !i.completed && new Date(i.date).getTime() > Date.now())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())[0];

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className={`min-h-screen ${isDarkMode ? "bg-[#0F172A] text-[#F8FAFC]" : "bg-slate-50 text-slate-900"} transition-colors duration-300 flex flex-col md:flex-row relative`}>
      {/* GLOW DECORATIONS - Enterprise Aesthetics */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] glow-accent-blue rounded-full pointer-events-none blur-3xl z-0"></div>
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] glow-accent-purple rounded-full pointer-events-none blur-3xl z-0"></div>

      {/* SIDEBAR NAVIGATION PANEL */}
      <aside className={`w-full md:w-64 border-b md:border-b-0 md:border-r ${isDarkMode ? "bg-[#0B0F19]/90 border-slate-850/80" : "bg-white border-slate-200"} flex flex-col justify-between shrink-0 z-10 relative`}>
        {/* Brand Block */}
        <div>
          <div className="p-6 border-b border-slate-900/40 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-primary to-brand-secondary flex items-center justify-center text-white font-black text-sm shadow-md shadow-brand-primary/20 pulse-glow">
              CCC
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight font-display text-white">Career Command</h1>
              <p className="text-[10px] text-brand-accent font-semibold tracking-wider uppercase">Track & Get Hired</p>
            </div>
          </div>

          {/* Nav Items Group */}
          <nav className="p-4 space-y-1">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "dashboard" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>Executive Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab("applications")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "applications" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <Briefcase className="w-4 h-4 shrink-0" />
              <span>Applications Matrix</span>
            </button>

            <button
              onClick={() => setActiveTab("kanban")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "kanban" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <History className="w-4 h-4 shrink-0" />
              <span>Board Pipeline</span>
            </button>

            <button
              onClick={() => setActiveTab("interviews")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "interviews" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <CalendarDays className="w-4 h-4 shrink-0" />
              <span>Interviews Hub</span>
            </button>

            <button
              onClick={() => setActiveTab("copilot")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all group ${
                activeTab === "copilot" ? "bg-indigo-600 text-white" : "text-indigo-400 hover:text-indigo-200 hover:bg-indigo-950/20"
              }`}
            >
              <Sparkles className="w-4 h-4 shrink-0 fill-indigo-400/20 group-hover:animate-pulse" />
              <span>Gemini AI Co-Pilot</span>
            </button>

            <button
              onClick={() => setActiveTab("database")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "database" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <Database className="w-4 h-4 shrink-0" />
              <span>MySQL & Flask DB</span>
            </button>

            <button
              onClick={() => setActiveTab("achievements")}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs md:text-sm font-medium transition-all ${
                activeTab === "achievements" ? "bg-brand-primary text-white" : "text-slate-400 hover:text-white hover:bg-slate-900/40"
              }`}
            >
              <Award className="w-4 h-4 shrink-0" />
              <span>Career Milestones</span>
            </button>
          </nav>
        </div>

        {/* Footer Settings Block */}
        <div className="p-4 border-t border-slate-900/40 space-y-2">
          {/* Theme & Actions Quick Group */}
          <div className="flex items-center justify-between px-3 text-slate-400">
            <span className="text-xs font-mono">2026 Shift</span>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-1 rounded-lg hover:text-white hover:bg-slate-900 transition-colors"
              title="Toggle Theme"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

          <button
            onClick={() => setActiveTab("settings")}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
              activeTab === "settings" ? "bg-slate-900 text-white" : "text-slate-450 hover:text-slate-200"
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Developer Sandbox</span>
          </button>
        </div>
      </aside>

      {/* CORE WORKSPACE SCREEN CONTAINER */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full z-10 relative">
        {/* TOP STATUS BAR CONTAINER */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-850/60 pb-5 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] bg-indigo-950/60 border border-indigo-900/40 text-indigo-300 font-semibold uppercase tracking-wider">
                Enterprise Suite 3.0
              </span>
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                <span>UTC Active</span>
              </span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold font-display tracking-tight text-white">
              {activeTab === "dashboard" && "SaaS Command Overview"}
              {activeTab === "applications" && "Applications Index Directory"}
              {activeTab === "kanban" && "High-Performance Workflows"}
              {activeTab === "interviews" && "Interview Schedules & Prep"}
              {activeTab === "copilot" && "AI Command Co-pilot Hub"}
              {activeTab === "database" && "Backend Schemas & Blueprints"}
              {activeTab === "achievements" && "Milestones & Achievements Locker"}
              {activeTab === "settings" && "General Controls & Sandbox Seeder"}
            </h2>
          </div>

          {/* Alerts & Actions Block */}
          <div className="flex items-center gap-3">
            {/* Quick Action Button */}
            <button
              onClick={() => openAppModal()}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-bold rounded-xl shadow-md hover:from-blue-700 hover:to-indigo-700 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Log Application</span>
            </button>

            {/* Notification drop center */}
            <div className="relative">
              <button
                onClick={() => setShowNotificationCenter(!showNotificationCenter)}
                className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-850 text-slate-350 hover:text-white flex items-center justify-center transition-all relative"
              >
                <Bell className="w-4 h-4" />
                {unreadNotificationsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-indigo-600 text-[10px] text-white flex items-center justify-center font-bold">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>

              {/* Mock Notification Hub UI */}
              {showNotificationCenter && (
                <div className="absolute right-0 mt-2.5 w-80 rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl p-4.5 z-50 animate-in fade-in-50 duration-200">
                  <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-3">
                    <span className="text-xs font-bold text-slate-300">Live Workspace Alerts</span>
                    <span className="text-[10px] text-indigo-400">Synchronized</span>
                  </div>
                  <div className="space-y-2.5">
                    {notifications.length > 0 ? (
                      notifications.map((n) => (
                        <div
                          key={n.id}
                          className={`p-3 rounded-xl text-xs leading-relaxed transition-all ${
                            n.read ? "bg-slate-900/30 text-slate-500" : "bg-slate-900 border border-slate-850 text-slate-200"
                          }`}
                        >
                          <p>{n.message}</p>
                          <div className="flex items-center justify-between mt-2.5 text-[9px] text-slate-500">
                            <span>{new Date(n.date).toLocaleDateString()}</span>
                            {!n.read && (
                              <button
                                onClick={() => handleDismissNotification(n.id)}
                                className="text-brand-accent hover:underline font-bold"
                              >
                                Mark Read
                              </button>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-6 text-xs text-slate-500">No active priority alerts tracked.</div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* --- DYNAMIC SECTION MANAGER RENDERERS --- */}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 gap-3.5">
            <Loader2 className="w-10 h-10 text-brand-accent animate-spin" />
            <span className="text-sm text-slate-400 font-mono tracking-widest uppercase">Initializing Command Console...</span>
          </div>
        ) : (
          <>
            {/* 1. DASHBOARD OVERVIEW */}
            {activeTab === "dashboard" && (
              <div className="space-y-8">
                {/* Hero section */}
                <div className="relative glass-panel rounded-2xl p-6 md:p-8 overflow-hidden border border-slate-800">
                  {/* Ambient absolute vector highlights */}
                  <div className="absolute top-0 right-0 w-96 h-96 bg-brand-primary/10 rounded-full blur-3xl pointer-events-none -mr-32 -mt-32"></div>
                  
                  <div className="max-w-xl relative">
                    <span className="inline-block text-[10px] font-bold text-brand-accent tracking-widest uppercase bg-cyan-950/50 border border-cyan-800/40 px-3 py-1 rounded-full mb-3.5">
                      Unified Search Console
                    </span>
                    <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight font-display text-white leading-tight">
                      Your Career Journey, <br />
                      <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-cyan-400 bg-clip-text text-transparent">Powered by Data.</span>
                    </h1>
                    <p className="mt-3 text-slate-400 text-sm md:text-base leading-relaxed">
                      Track job applications, monitor core interview pipelines, trigger automated GPT resume enhancements, and land your next opportunity faster.
                    </p>

                    <div className="mt-6.5 flex flex-wrap gap-3">
                      <button
                        onClick={() => setActiveTab("copilot")}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-indigo-600/10 cursor-pointer"
                      >
                        <Sparkles className="w-4 h-4 fill-indigo-400" />
                        <span>Launch Gemini Optimizer</span>
                      </button>
                      <button
                        onClick={() => openAppModal()}
                        className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 font-bold text-xs rounded-xl border border-slate-800 flex items-center gap-2 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Application Record</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* KPI CARDS GRID */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Total applications card */}
                  <div className="glass-panel-interactive p-5 rounded-2xl border border-slate-850">
                    <div className="text-slate-450 text-[10px] font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5 justify-between">
                      <span>Total Applications</span>
                      <Briefcase className="w-4 h-4 text-blue-500" />
                    </div>
                    <div className="text-3xl font-extrabold font-display text-white">{totalAppsCount}</div>
                    <div className="text-[10px] text-slate-500 mt-2 flex items-center gap-1">
                      <span className="text-emerald-400 font-bold">{appsThisMonthCount} logged</span>
                      <span>this calendar month</span>
                    </div>
                  </div>

                  {/* Interviews planned card */}
                  <div className="glass-panel-interactive p-5 rounded-2xl border border-slate-850">
                    <div className="text-slate-450 text-[10px] font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5 justify-between">
                      <span>Upcoming Screens</span>
                      <CalendarDays className="w-4 h-4 text-purple-500" />
                    </div>
                    <div className="text-3xl font-extrabold font-display text-white">{interviewsCount}</div>
                    <div className="text-[10px] text-slate-500 mt-2 flex items-center gap-1.5 truncate">
                      {nextUpcomingInterview ? (
                        <span className="text-indigo-400 font-semibold truncate animate-pulse">
                          Next: {new Date(nextUpcomingInterview.date).toLocaleDateString()}
                        </span>
                      ) : (
                        <span>No priority screens queued</span>
                      )}
                    </div>
                  </div>

                  {/* Success Rate Card */}
                  <div className="glass-panel-interactive p-5 rounded-2xl border border-slate-850">
                    <div className="text-slate-450 text-[10px] font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5 justify-between">
                      <span>Offers Secured</span>
                      <CheckCircle className="w-4 h-4 text-emerald-500" />
                    </div>
                    <div className="text-3xl font-extrabold font-display text-white">{offersCount}</div>
                    <div className="text-[10px] text-slate-500 mt-2 flex items-center gap-1">
                      <span className="text-emerald-400 font-bold">{successRate}% success</span>
                      <span>over tracked pipelines</span>
                    </div>
                  </div>

                  {/* Rejected tracking */}
                  <div className="glass-panel-interactive p-5 rounded-2xl border border-slate-850">
                    <div className="text-slate-450 text-[10px] font-bold uppercase tracking-wider mb-2 flex items-center gap-1.5 justify-between">
                      <span>Rejected Tracks</span>
                      <AlertCircle className="w-4 h-4 text-rose-500" />
                    </div>
                    <div className="text-3xl font-extrabold font-display text-rose-450">{rejectionsCount}</div>
                    <div className="text-[10px] text-slate-500 mt-2">
                      <span>Response callback: </span>
                      <span className="text-brand-accent font-bold">{responseRate}%</span>
                    </div>
                  </div>
                </div>

                {/* DYNAMIC PIPELINE SPLIT GAGE & GAMIFICATION BANNER */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Active List summary logs */}
                  <div className="lg:col-span-8 space-y-6">
                    {/* Simplified Charts Preview block */}
                    <div className="glass-panel rounded-2xl p-6 border border-slate-800">
                      <div className="flex items-center justify-between mb-6">
                        <div>
                          <h3 className="text-sm font-bold text-white font-display">Applications Funnel Distribution</h3>
                          <p className="text-[11px] text-slate-400">Total pipeline volumes categorized</p>
                        </div>
                        <button onClick={() => setActiveTab("copilot")} className="text-xs text-brand-accent hover:underline flex items-center gap-1 font-semibold">
                          <span>Verify with Copilot</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                        {[
                          { label: "Applied", filterKey: "Applied", color: "bg-blue-500" },
                          { label: "Under Review", filterKey: "Under Review", color: "bg-amber-500" },
                          { label: "Assessment", filterKey: "Assessment", color: "bg-cyan-500" },
                          { label: "Interviews", filterKey: "Interview Scheduled", color: "bg-purple-500" },
                          { label: "Offers Gained", filterKey: "Offer Received", color: "bg-emerald-500" }
                        ].map((stat, idx) => {
                          const count = applications.filter(a => a.status === stat.filterKey || (stat.filterKey === "Interview Scheduled" && a.status === ApplicationStatus.FinalRound)).length;
                          return (
                            <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-900 text-center flex flex-col justify-between">
                              <span className="text-[10px] font-bold text-slate-450 uppercase mb-2 block truncate">{stat.label}</span>
                              <div className="text-xl font-bold text-white">{count}</div>
                              <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden mt-3">
                                <div className={`h-full ${stat.color}`} style={{ width: `${totalAppsCount ? Math.round((count / totalAppsCount)*100) : 0}%` }}></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Quick Active Table Preview */}
                    <div className="glass-panel p-5 rounded-2xl border border-slate-800">
                      <div className="flex items-center justify-between pb-4 border-b border-slate-900 mb-4">
                        <h3 className="text-sm font-bold text-white font-display">Active Priority Applications</h3>
                        <button onClick={() => setActiveTab("applications")} className="text-xs text-brand-accent hover:underline flex items-center gap-1 font-semibold">
                          <span>See Complete Directory</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="space-y-3.5">
                        {applications.length > 0 ? (
                          applications.slice(0, 4).map((app) => (
                            <div
                              key={app.id}
                              onClick={() => setViewingAppDetails(app)}
                              className="bg-slate-950 hover:bg-slate-900/60 p-4 rounded-xl border border-slate-850 hover:border-slate-800 transition-all flex items-center justify-between gap-3 cursor-pointer"
                            >
                              <div className="min-w-0">
                                <h4 className="text-xs font-bold text-white truncate">{app.companyName}</h4>
                                <p className="text-[11px] text-slate-400 truncate mt-0.5">{app.role}</p>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-semibold ${getStatusStyle(app.status)}`}>
                                  {app.status}
                                </span>
                                <span className="text-[10px] text-slate-500 font-mono hidden sm:inline">{app.applicationDate}</span>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-10 text-xs text-slate-500 border border-dashed border-slate-850 rounded-xl">
                            No logs added yet. Add records using the Log Application form!
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Sidebar Gamification and Alerts locker */}
                  <div className="lg:col-span-4 space-y-6">
                    {/* Gamified Habit Streak block */}
                    <div className="glass-panel p-5 rounded-2xl border border-slate-800 relative bg-gradient-to-br from-slate-900/40 via-slate-900/20 to-indigo-950/20">
                      <div className="flex items-center justify-between mb-4.5">
                        <span className="text-xs font-bold text-slate-350 tracking-wider flex items-center gap-1">
                          <Flame className="w-4 h-4 text-brand-warning animate-bounce" />
                          <span>Habit Streak</span>
                        </span>
                        <span className="text-[10px] bg-amber-955 text-brand-warning bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20 font-bold">
                          Lv. 4 Commander
                        </span>
                      </div>

                      <div className="text-center py-3">
                        <div className="text-4xl font-black font-display text-white tracking-tight flex items-center justify-center gap-1.5">
                          <span>{dashboardMeta.streak}</span>
                          <span className="text-lg text-slate-400">Days Solid</span>
                        </div>
                        <p className="text-[11px] text-slate-450 leading-relaxed mt-2.5 max-w-[210px] mx-auto">
                          Keep adding applications, rescheduling filters, and utilizing the co-pilot to retain active multipliers!
                        </p>
                      </div>

                      {/* Goal progress indicator */}
                      <div className="mt-4 pt-4 border-t border-slate-900/60 text-xs space-y-1.5">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-slate-400 font-medium">Weekly Log Goal</span>
                          <span className="text-white font-bold">
                            {dashboardMeta.weeklyGoal?.progress} / {dashboardMeta?.weeklyGoal?.target}
                          </span>
                        </div>
                        <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-900">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transition-all duration-300"
                            style={{
                              width: `${
                                ((dashboardMeta.weeklyGoal?.progress || 3) / (dashboardMeta.weeklyGoal?.target || 5)) * 100
                              }%`
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {/* Achievement Badges Banner */}
                    <div className="glass-panel p-5 rounded-2xl border border-slate-850">
                      <div className="flex items-center justify-between border-b border-slate-900 pb-3 mb-3.5">
                        <h4 className="text-xs font-bold text-white font-display">Badges Ledger</h4>
                        <button onClick={() => setActiveTab("achievements")} className="text-[10px] text-indigo-400 hover:underline">
                          View Store
                        </button>
                      </div>

                      <div className="grid grid-cols-4 gap-2 text-center">
                        {dashboardMeta.achievements &&
                          dashboardMeta.achievements.map((ach) => (
                            <div
                              key={ach.id}
                              className={`p-2 rounded-xl border flex flex-col items-center justify-center relative ${
                                ach.unlocked
                                  ? "bg-slate-950 border-indigo-500/30 text-white"
                                  : "bg-slate-900/40 border-slate-850 text-slate-600"
                              }`}
                              title={`${ach.badge}: ${ach.description}`}
                            >
                              <Award className={`w-6 h-6 mb-1 ${ach.unlocked ? "text-indigo-400" : "text-slate-800"}`} />
                              <span className="text-[9px] font-semibold truncate max-w-full block leading-none">{ach.badge.split(" ")[0]}</span>
                              {ach.unlocked && (
                                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-brand-success rounded-full ring-2 ring-slate-950 animate-ping"></span>
                              )}
                            </div>
                          ))}
                      </div>
                    </div>

                    {/* Recent audit trails logs summary */}
                    <div className="glass-panel p-5 rounded-2xl border border-slate-850">
                      <h4 className="text-xs font-bold text-slate-350 uppercase tracking-widest mb-3.5">Unified System Audit Trails</h4>
                      <div className="space-y-3 max-h-56 overflow-y-auto scrollbar-thin">
                        {dashboardMeta.activityLogs && dashboardMeta.activityLogs.slice(0, 4).map((log) => (
                          <div key={log.id} className="text-xs leading-normal flex items-start gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-900">
                            <span className="text-brand-accent mt-0.5">•</span>
                            <div>
                              <p className="text-slate-300 font-medium">{log.action}</p>
                              <span className="text-[9px] text-slate-500 block mt-0.5">{new Date(log.timestamp).toLocaleTimeString()}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 2. APPLICATIONS DIRECTORY */}
            {activeTab === "applications" && (
              <div className="space-y-6">
                {/* Filters, sort header */}
                <div className="glass-panel p-4 rounded-xl border border-slate-800 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3.5">
                  {/* Search input */}
                  <div className="flex-1 relative">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 py-0.5 h-4 text-slate-500" />
                    <input
                      type="text"
                      className="w-full bg-slate-950 hover:bg-slate-950/80 text-xs md:text-sm text-slate-200 pl-10 pr-4 py-2.5 rounded-xl border border-slate-850 focus:outline-none focus:border-indigo-500 transition-all font-medium"
                      placeholder="Search company, job role titles, location or custom notes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>

                  {/* Dropdowns filters */}
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-1.5 flex-1 sm:flex-initial">
                      <SlidersHorizontal className="w-4 h-4 text-slate-450 shrink-0" />
                      <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-xl px-3 py-2 focus:outline-none"
                      >
                        <option value="All">All Stages</option>
                        {Object.values(ApplicationStatus).map((stat) => (
                          <option key={stat} value={stat}>
                            {stat}
                          </option>
                        ))}
                      </select>
                    </div>

                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-xl px-3 py-2 focus:outline-none flex-1 sm:flex-initial"
                    >
                      <option value="date">Added Date</option>
                      <option value="salary">Compensation</option>
                      <option value="company">Corporate Name</option>
                    </select>

                    <button
                      onClick={exportToCSV}
                      className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-bold transition-all flex items-center gap-1.5 shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>CSV Exporter</span>
                    </button>
                  </div>
                </div>

                {/* Primary List Display Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredAndSortedApps.length > 0 ? (
                    filteredAndSortedApps.map((app) => (
                      <div
                        key={app.id}
                        className="glass-panel-interactive rounded-2xl p-5 border border-slate-850 flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-1 mb-2">
                            <span className={`text-[9px] px-2.5 py-0.5 rounded-full font-bold uppercase ${getStatusStyle(app.status)}`}>
                              {app.status}
                            </span>
                            <span className="text-[10px] text-slate-550 font-mono shrink-0">{app.applicationDate}</span>
                          </div>

                          <h3 className="text-md font-extrabold text-white font-display leading-tight truncate">{app.companyName}</h3>
                          <p className="text-xs font-semibold text-slate-350 truncate mt-0.5">{app.role}</p>

                          {/* Specific notes preview */}
                          {app.notes && (
                            <p className="text-[11px] text-slate-450 line-clamp-2 mt-3 p-2 bg-slate-950 rounded-lg border border-slate-900 leading-relaxed italic">
                              "{app.notes}"
                            </p>
                          )}
                        </div>

                        <div className="border-t border-slate-900/60 pt-4 mt-4 space-y-3">
                          <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 gap-1">
                            <span>Compensation: <span className="text-white font-mono">{app.salary || "Not Specified"}</span></span>
                            <span>{app.location}</span>
                          </div>

                          <div className="flex items-center gap-2 pt-1 border-t border-slate-950/20">
                            {/* Detailed view */}
                            <button
                              onClick={() => setViewingAppDetails(app)}
                              className="flex-1 bg-slate-950 hover:bg-slate-900 text-slate-300 text-xs py-1.5 px-2 rounded-lg transition-colors border border-slate-850 cursor-pointer font-bold"
                            >
                              View Specs
                            </button>
                            {/* Update/Edit */}
                            <button
                              onClick={() => openAppModal(app)}
                              className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white transition-colors"
                              title="Edit application profile"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            {/* Add interview link */}
                            <button
                              onClick={() => openIntModal(app.id)}
                              className="p-1.5 rounded-lg bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 transition-colors border border-indigo-900/10"
                              title="Schedule coupled interview slot"
                            >
                              <CalendarDays className="w-3.5 h-3.5" />
                            </button>
                            {/* Delete */}
                            <button
                              onClick={() => deleteApplicationRecord(app.id)}
                              className="p-1.5 rounded-lg hover:bg-rose-950/20 text-slate-500 hover:text-rose-400 transition-colors ml-auto"
                              title="Delete record index"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-full py-20 text-center text-slate-500 bg-slate-950/20 rounded-2xl border border-dashed border-slate-800">
                      <Briefcase className="w-10 h-10 text-slate-800 mx-auto mb-2" />
                      <p className="text-sm">No matched application traces discovered.</p>
                      <button onClick={() => syncAllData()} className="text-xs text-brand-accent hover:underline mt-2">
                        Refresh Database Connection
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 3. KANBAN WORKFLOW SECTION */}
            {activeTab === "kanban" && (
              <div className="glass-panel rounded-2xl p-5 border border-slate-800">
                <KanbanBoard
                  applications={applications}
                  onUpdateStatus={handleUpdateAppStatus}
                  onSelectApplication={(a) => setViewingAppDetails(a)}
                />
              </div>
            )}

            {/* 4. INTERVIEWS HUB */}
            {activeTab === "interviews" && (
              <div className="space-y-6">
                {/* Schedule Header */}
                <div className="glass-panel p-5 rounded-xl border border-slate-805 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-md font-bold text-white font-display mb-1">Interview Queues Scheduling Control</h3>
                    <p className="text-xs text-slate-400">Log upcoming screens, tech panels and system checks here</p>
                  </div>
                  <button
                    onClick={() => openIntModal()}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Log New Stage</span>
                  </button>
                </div>

                {/* Upcoming List and feedback logs */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Event slots */}
                  <div className="lg:col-span-8 space-y-4">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest pl-1 mb-2">Priority Screen Targets</h3>
                    {interviews.length > 0 ? (
                      interviews.map((int) => {
                        const coupledApp = applications.find((a) => a.id === int.applicationId);
                        const daysLeftStr = getDaysUntil(int.date);
                        return (
                          <div
                            key={int.id}
                            className="bg-slate-950 p-5 rounded-2xl border border-slate-850 hover:border-slate-800 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative overflow-hidden"
                          >
                            <div className="absolute top-0 left-0 w-[2px] h-full bg-gradient-to-b from-indigo-500 to-purple-500"></div>
                            
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="inline-block text-[10px] bg-indigo-950/50 border border-indigo-900/30 text-indigo-300 px-2 py-0.2 rounded font-mono font-bold">
                                  {int.type}
                                </span>
                                {coupledApp && (
                                  <span className="text-xs text-slate-400 font-medium">@ {coupledApp.companyName}</span>
                                )}
                              </div>
                              <h4 className="text-sm font-extrabold text-white font-display leading-tight">{int.title}</h4>
                              <p className="text-[11px] text-slate-450 flex items-center gap-1">
                                <Clock className="w-3.5 h-3.5 shrink-0 text-brand-accent animate-pulse" />
                                <span>{new Date(int.date).toLocaleString()}</span>
                              </p>
                              {int.notes && <p className="text-[11px] text-slate-400 leading-relaxed mt-2 italic">Notes: "{int.notes}"</p>}
                            </div>

                            {/* Actions column */}
                            <div className="flex items-center gap-3.5 shrink-0 border-t sm:border-t-0 border-slate-900 pt-3 sm:pt-0">
                              {int.zoomLink && (
                                <a
                                  href={int.zoomLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="px-3.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-brand-accent text-xs font-semibold flex items-center gap-1.5 border border-slate-800"
                                >
                                  <ExternalLink className="w-3.5 h-3.5" />
                                  <span>Join Zoom Link</span>
                                </a>
                              )}

                              <div className="text-right">
                                <div className="text-xs font-bold font-display text-white">{daysLeftStr}</div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="bg-slate-950/20 rounded-2xl border border-dashed border-slate-800 text-center py-16 text-xs text-slate-500">
                        No active interviews scheduled currently. Secure callbacks first!
                      </div>
                    )}
                  </div>

                  {/* AI Interview Prep Assistant Widget */}
                  <div className="lg:col-span-4 bg-slate-950 rounded-2xl p-5 border border-slate-850">
                    <Sparkles className="w-8 h-8 text-indigo-400 fill-indigo-400/10 mb-3" />
                    <h4 className="text-sm font-bold text-slate-100 font-display">Live AI Prep Workshop</h4>
                    <p className="text-xs text-slate-400 leading-relaxed mt-1.5 mb-4">
                      Obtain real-world technical screen questions custom targeted to your actual scheduled opportunities!
                    </p>
                    <button
                      onClick={() => setActiveTab("copilot")}
                      className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow"
                    >
                      <span>Launch Copilot prep panel</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 5. GEMINI CO-PILOT HUB */}
            {activeTab === "copilot" && (
              <div className="space-y-6">
                <AICopilotHub />
              </div>
            )}

            {/* 6. SAAS DEVELOPMENT SUITE */}
            {activeTab === "database" && (
              <div className="space-y-6">
                <SaaSDevCenter />
              </div>
            )}

            {/* 7. ACHIEVEMENT Badges display */}
            {activeTab === "achievements" && (
              <div className="space-y-6">
                {/* Overview banner */}
                <div className="p-5 rounded-2xl bg-gradient-to-tr from-slate-900 via-indigo-950/20 to-slate-900 border border-slate-850 text-center">
                  <Award className="w-12 h-12 text-indigo-400 mx-auto fill-indigo-500/10 mb-2.5 animate-pulse" />
                  <h3 className="text-md font-bold font-display text-white">Milestone Gamification Hub</h3>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed mt-1">
                    Track search milestones, log application caps overtime and secure unlock rewards to optimize your focus streak!
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {dashboardMeta.achievements &&
                    dashboardMeta.achievements.map((ach) => (
                      <div
                        key={ach.id}
                        className={`p-5 rounded-2xl border flex flex-col justify-between h-44 transition-all ${
                          ach.unlocked
                            ? "bg-slate-950 border-indigo-500/30 text-white shadow-xl shadow-indigo-600/5"
                            : "bg-slate-900/40 border-slate-850 text-slate-450"
                        }`}
                      >
                        <div>
                          <Award className={`w-8 h-8 mb-2 ${ach.unlocked ? "text-indigo-400" : "text-slate-800"}`} />
                          <h4 className="text-xs font-bold block">{ach.badge}</h4>
                          <p className="text-[11px] text-slate-450 leading-relaxed mt-1">{ach.description}</p>
                        </div>
                        <div className="text-[9px] text-slate-500 italic mt-3 border-t border-slate-900/60 pt-2 flex items-center justify-between">
                          <span>Status: {ach.unlocked ? "Unlocked" : "Locked"}</span>
                          {ach.unlocked && ach.unlockedAt && <span>{new Date(ach.unlockedAt).toLocaleDateString()}</span>}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* 8. GENERAL SETTINGS */}
            {activeTab === "settings" && (
              <div className="glass-panel p-6 rounded-2xl border border-slate-800 space-y-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-red-500/5 rounded-full blur-3xl pointer-events-none -mr-32 -mt-32"></div>

                <div className="max-w-md">
                  <h3 className="text-lg font-bold font-display text-white mb-2">Portfolio Sandbox Control Panel</h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-6">
                    This panel provides core developer seeder features to assist reviewers in assessing full dynamic pipeline responses and database mutations.
                  </p>

                  <div className="space-y-4 pt-4 border-t border-slate-900">
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">Database Reseeding Sandbox</h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Resetting restores the high-fidelity demo targets (Google, Stripe, Linear, Notion, Vercel) across all applications and interviews grids.
                      </p>
                      <button
                        onClick={handleResetSeedData}
                        className="px-4 py-2 border border-slate-800 bg-slate-900 hover:bg-slate-800 rounded-xl text-xs text-slate-100 font-bold transition-all cursor-pointer"
                      >
                        Restore Sandbox Seed Demo
                      </button>
                    </div>

                    <div className="space-y-2 pt-5 border-t border-slate-900">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">CSV & excel data exporters</h4>
                      <p className="text-xs text-slate-400">Export active logs instantly to offline formats:</p>
                      <div className="flex gap-2">
                        <button
                          onClick={exportToCSV}
                          className="px-3.5 py-1.8 rounded-lg bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-400 border border-indigo-900/10 text-xs font-semibold flex items-center gap-1"
                        >
                          <FileSpreadsheet className="w-3.5 h-3.5" />
                          <span>Download .CSV</span>
                        </button>
                        <button
                          onClick={exportToExcelFormat}
                          className="px-3.5 py-1.8 rounded-lg bg-teal-950/40 hover:bg-teal-900/40 text-teal-400 border border-teal-900/10 text-xs font-semibold flex items-center gap-1"
                        >
                          <FileCode2 className="w-3.5 h-3.5" />
                          <span>Download .XLS</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* --- FLOATING DIALOGS & OVERLAY SLIDERS (MODALS) --- */}

      {/* 1. APPLICATION LOG MODAL */}
      {isAppModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-[#1E293B] border border-slate-800 rounded-2xl max-w-xl w-full p-6 relative shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto scrollbar-thin">
            <h3 className="text-lg font-bold font-display text-white mb-1">
              {editingApp ? "Modify Application Log" : "Log New Target Application"}
            </h3>
            <p className="text-xs text-slate-400 mb-5">Ensure accurate metrics for correct ATS grading alignment.</p>

            <form onSubmit={handleAppSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3.5">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Company Name *</label>
                  <input
                    type="text"
                    required
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    className="bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-indigo-500"
                    placeholder="Stripe, Vercel..."
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Role Title *</label>
                  <input
                    type="text"
                    required
                    value={formRole}
                    onChange={(e) => setFormRole(e.target.value)}
                    className="bg-slate-950 border border-slate-800 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none"
                    placeholder="Senior Frontend Architect..."
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3.5">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Location</label>
                  <input
                    type="text"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                    placeholder="San Francisco / Remote"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Compensation Range</label>
                  <input
                    type="text"
                    value={formSalary}
                    onChange={(e) => setFormSalary(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                    placeholder="$160,000 - $180,000"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Application Date</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Application URL / Link</label>
                <input
                  type="url"
                  value={formJobLink}
                  onChange={(e) => setFormJobLink(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                  placeholder="https://careers.company.com/job-post"
                />
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Recruiter Name</label>
                  <input
                    type="text"
                    value={formRecruiterName}
                    onChange={(e) => setFormRecruiterName(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                    placeholder="Full name contact"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Recruiter Email</label>
                  <input
                    type="email"
                    value={formRecruiterEmail}
                    onChange={(e) => setFormRecruiterEmail(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                    placeholder="r.contact@company.com"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Current Stage Status *</label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as ApplicationStatus)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-200"
                  >
                    {Object.values(ApplicationStatus).map((status) => (
                      <option key={status} value={status}>
                        {status}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Strategic internal logs & Notes</label>
                <textarea
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none text-slate-200 scrollbar-thin resize-none h-20"
                  placeholder="Record interview notes, target metrics, team members..."
                />
              </div>

              <div className="pt-4 border-t border-slate-900 flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={closeAppModal}
                  className="px-4.5 py-2 border border-slate-800 text-slate-400 hover:text-white rounded-xl"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4.5 py-2 bg-brand-primary text-white font-bold rounded-xl shadow">
                  {editingApp ? "Save Changes" : "Log Track Record"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. DATED INTERVIEW SCHEDULER MODAL */}
      {isIntModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-[#1E293B] border border-slate-800 rounded-2xl max-w-md w-full p-6 relative shadow-2xl animate-in zoom-in-95 duration-200">
            <h3 className="text-lg font-bold font-display text-white mb-1">Schedule Stage Interview</h3>
            <p className="text-xs text-slate-400 mb-5">Schedule a live countdown tracking slot against parent track.</p>

            <form onSubmit={handleIntSubmit} className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Associate Target Application *</label>
                <select
                  value={selectedAppForInt}
                  onChange={(e) => setSelectedAppForInt(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none"
                >
                  {applications.map((app) => (
                    <option key={app.id} value={app.id}>
                      {app.companyName} — {app.role}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Stage / Panel Name *</label>
                <input
                  type="text"
                  required
                  value={formIntTitle}
                  onChange={(e) => setFormIntTitle(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none"
                  placeholder="E.g., Systems and Architecture Screen"
                />
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Scheduled date & Time *</label>
                  <input
                    type="datetime-local"
                    required
                    value={formIntDate}
                    onChange={(e) => setFormIntDate(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs focus:outline-none text-slate-420"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-305">Interview Format Type</label>
                  <input
                    type="text"
                    value={formIntType}
                    onChange={(e) => setFormIntType(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs"
                    placeholder="WebGL/Systems design"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Video Call Zoom URL Link</label>
                <input
                  type="url"
                  value={formIntZoom}
                  onChange={(e) => setFormIntZoom(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs"
                  placeholder="https://zoom.us/j/928210392"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-305">Extra detail hints</label>
                <textarea
                  value={formIntNotes}
                  onChange={(e) => setFormIntNotes(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs scrollbar-thin resize-none h-16 text-slate-200"
                  placeholder="e.g. interviewer name tags, algorithms focus areas..."
                />
              </div>

              <div className="pt-4 border-t border-slate-900 flex justify-end gap-2 text-xs">
                <button
                  type="button"
                  onClick={closeIntModal}
                  className="px-4.5 py-2 border border-slate-800 text-slate-400 hover:text-white rounded-xl animate-none"
                >
                  Cancel
                </button>
                <button type="submit" className="px-4.5 py-2 bg-brand-primary text-white font-bold rounded-xl shadow cursor-pointer">
                  Setup Schedule Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. APPLICATION IN-DEPTH VIEW POP PANEL */}
      {viewingAppDetails && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-[#1E293B] border border-slate-800 rounded-2xl max-w-xl w-full p-6 relative shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto scrollbar-thin">
            <div className="absolute top-0 right-0 w-44 h-44 bg-brand-primary/5 rounded-full blur-2xl pointer-events-none"></div>

            <div className="flex items-start justify-between border-b border-slate-850 pb-4 mb-4 relative z-10">
              <div>
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase ${getStatusStyle(viewingAppDetails.status)}`}>
                  {viewingAppDetails.status}
                </span>
                <h3 className="text-xl font-extrabold text-white font-display mt-2 leading-tight">{viewingAppDetails.companyName}</h3>
                <p className="text-xs text-slate-400 font-semibold">{viewingAppDetails.role}</p>
              </div>
              <button
                onClick={() => setViewingAppDetails(null)}
                className="w-8 h-8 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white flex items-center justify-center border border-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-900">
                <div>
                  <span className="text-slate-500 uppercase tracking-widest text-[9px] block">Location Parameters</span>
                  <span className="text-slate-200 font-medium">{viewingAppDetails.location}</span>
                </div>
                <div>
                  <span className="text-slate-500 uppercase tracking-widest text-[9px] block">Target Salary Scale</span>
                  <span className="text-emerald-400 font-mono font-medium">{viewingAppDetails.salary || "Not Specified"}</span>
                </div>
                <div className="mt-2.5">
                  <span className="text-slate-500 uppercase tracking-widest text-[9px] block">Log Submission Date</span>
                  <span className="text-slate-200">{viewingAppDetails.applicationDate}</span>
                </div>
                {viewingAppDetails.jobLink && (
                  <div className="mt-2.5">
                    <span className="text-slate-500 uppercase tracking-widest text-[9px] block">Job Board Link</span>
                    <a
                      href={viewingAppDetails.jobLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-brand-accent hover:underline flex items-center gap-1 font-semibold"
                    >
                      <span>Jump to Job Board</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                )}
              </div>

              {/* Recruiter Details Box */}
              {(viewingAppDetails.recruiterName || viewingAppDetails.recruiterEmail) && (
                <div className="p-3.5 rounded-xl border border-slate-850/60 bg-slate-900/60">
                  <h4 className="font-bold text-slate-350 pr-1 mb-1 bg-clip-border text-[10px] uppercase tracking-wider">Contact Recruiter Information</h4>
                  <div className="space-y-1 mt-1 font-mono text-[11px]">
                    {viewingAppDetails.recruiterName && (
                      <p className="text-slate-300">Name: <span className="text-white font-sans">{viewingAppDetails.recruiterName}</span></p>
                    )}
                    {viewingAppDetails.recruiterEmail && (
                      <p className="text-slate-300">
                        Email: <a href={`mailto:${viewingAppDetails.recruiterEmail}`} className="text-brand-accent hover:underline">{viewingAppDetails.recruiterEmail}</a>
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Internal Notes */}
              <div>
                <span className="text-slate-500 text-[10px] uppercase tracking-wide font-bold">Strategic Search Log Notes</span>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-900 text-slate-300 leading-relaxed max-h-40 overflow-y-auto whitespace-pre-wrap">
                  {viewingAppDetails.notes || "No extra personal reminders recorded index. Update via editing."}
                </div>
              </div>

              {/* Actions segment */}
              <div className="pt-4 border-t border-slate-900/80 flex items-center gap-2">
                <button
                  onClick={() => {
                    openAppModal(viewingAppDetails);
                    setViewingAppDetails(null);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl flex items-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Update Details</span>
                </button>
                <button
                  onClick={() => deleteApplicationRecord(viewingAppDetails.id)}
                  className="px-4 py-2 bg-rose-950/20 text-rose-400 hover:bg-rose-950/40 rounded-xl"
                >
                  Delete Record
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
